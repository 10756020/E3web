var express = require('express');
var router = express.Router();
var formidable = require('formidable');
var fs = require('fs');
var connect = require('../Database/dbconnection.js');
var cookie = require('cookie-parser');
var bodyParser = require('body-parser');

router.get('/',function(req,res,next){
    if(req.session.email&&req.session.status==2){
        res.render('asking');
    }else if(req.session.email){
        res.redirect('/');
    }else{
        res.redirect('/login');
    }
    
})
router.post('/',function(req,res,next){
    var teacher = req.session.email;
    var form = new formidable.IncomingForm();
        form.parse(req,function(err,fields,files){
            console.log(files.filetoupload.filepath);
            console.log("測試")
            console.log(files);
            console.log("測試")
            console.log(fields);
            console.log(fields.textbar);
            var question = fields.textbarQuestion;
            var answer = fields.textbarAnswer;
            var oldpath = files.filetoupload.filepath;
            var newpath = 'C:/Users/Covington/Desktop/專題/project/express-locallibrary-tutorial/picture/' + files.filetoupload.originalFilename
            if(files.filetoupload.originalFilename){
                fs.rename(oldpath,newpath,function(err){
                    if(err) throw err;
                    console.log('已完成上傳檔案');           
                })
            }else{
                console.log('沒有要上傳的圖檔');
            }        
            connect.query('insert into `111- E3Web`.AssayQuestion(Question,Answer,PhotoPath,Unit,Setter) values(?,?,?,?,?)',[question,answer,files.filetoupload.originalFilename,fields.Unit,teacher],function(err){
                if(err) throw err;
                console.log('題目及解答已放入DB');
            })
        })
        
        
    
    res.redirect('/asking')
});




module.exports = router;