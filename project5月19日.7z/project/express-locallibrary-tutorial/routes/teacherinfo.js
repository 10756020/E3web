var express = require('express');
var router = express.Router();
var connect = require('../Database/dbconnection.js');
var cookie = require('cookie-parser');
var bodyParser = require('body-parser');
var bcrypt = require('bcrypt');
const saltRound = 5;

router.get('/',function(req,res,next){
    if(req.session.email&&req.session.status==2){
        res.render('teacherinfo',{account:req.session.email});
    }else if(req.session.email){
        res.redirect('/');
    }else{
        res.redirect('/login');
    }
    
})

router.post('/',function(req,res,next){
    var ps = req.body.changedPassword
    connect.query('UPDATE `111- E3Web`.UserData SET password=? where email =?',[bcrypt.hashSync(ps,saltRound),req.session.email],function(err){
        if(err) throw err;
        console.log('已成功更改密碼');
        res.redirect('/');
    })
})


module.exports = router;