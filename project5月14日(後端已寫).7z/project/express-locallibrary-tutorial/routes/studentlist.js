var express = require('express');
var router = express.Router();
var connection = require('../Database/dbconnection.js');

router.get('/',function(req,res,next){
    if(req.session.email&&req.session.status==2){
        connection.query('select email from `111- E3Web`.UserData where status=? order by email desc',['學生'],function(err,user){
            console.log(user);
            res.render('studentlist',{users:user});
        })
        
    }else if(req.session.email&&req.session.status==1){
        res.redirect('/');
    }else{
        res.redirect('/login');
    }
    
})



module.exports = router;