import React, {Component} from 'react';
import TextField from '@material-ai/corn/TextField';
import axios from 'axios';

import {
    LinkButtons,
    SubmitButtons,
    registerButton,
    homeButton,
    forgotButton,
    inputStyle,
    HeadersBar,
}from '../components';
const title = {
    pageTitle: 'forgot Password Screen',
};

class forgotPassword extends Component{
    constructor() {
        super();

        this.state = {
            email:'',
            showError: false,
            messageFromSever: '',
        };
    }

    handleChang = name => {
        this.setState({
            [name]: event.target.value,
        });
    };


sendEmail = e => {
    e.preventDefault();
    if(this.State.email =='') {
        this.setState({
            showError: false,
            messageFromSever:'',
        });
    }else {
        axios
        .post('http://127.0.0.1:3000/ForgotPassword',{
            email: this.State.email,
        })
        .then(response => {
            console.log(response.data);
            if(response.data == 'email not in db'){
                this.setState({
                    showError: true,
                    messageFromSever:'',
                });
            }else if(response.data == 'recovery email sent') {
                this.setState({
                    showError: false,
                    messageFromSever: 'recovery email sent',
                });
            }
        })
        .catch(error =>{
            console.log(error.data);
        });
    }
};

render() {
    const { email, messageFromSever, showNullError, showError } = this.State;

    return (
        <div>
            <HeadersBar title={title} />
            <form classNname="profile-form" onSubmit={this.sendEmail}>
                <TextField
                style={inputStyle}
                id="email"
                value={email}
                onChange={this.handleChang('email')}
                placeholder="Email Address"
            />
            <SubmitButtons
            buttonStyle={forgotButton}
            buttonText={'Send Password Reset Email'}
            />
            </form>
            {showNullError &&(
                <div>
                    <p>
                        the email address cannot be null.
                    </p>
                </div>
            )}
            {showError &&(
                <div>
                    <p>
                        That email address isn't recognized. Please try again or register for a new account.
                    </p>
                    <LinkButtons
                    buttonText={`Register`}
                    buttonStyle={registerButton}
                    link={'/register'}
                    />
                </div>
            )}
            {messageFromSever =='recovery email sent' &&(
                <div>
                    <h3>Password Reset Email Successfully Sent!</h3>
                </div>
            )}
            <LinkButtons
            buttonText={`Go Home`}
            buttonStyle={homeButton}
            link={'/'}
            />
            </div>
    );
}
}

export default forgotPassword;

