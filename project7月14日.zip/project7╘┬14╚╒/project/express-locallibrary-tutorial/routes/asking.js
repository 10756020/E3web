var express = require('express');
var router = express.Router();
var formidable = require('formidable');
var fs = require('fs');
var connect = require('../Database/dbconnection.js');
var cookie = require('cookie-parser');
var bodyParser = require('body-parser');

router.get('/',function(req,res,next){
    if(req.session.email&&req.session.status==2){
        res.render('asking');
    }else if(req.session.status==1||req.session.status==3){
        res.redirect('/');
    }else{
        res.redirect('/login');
    }
    
})
router.post('/',function(req,res,next){
    var teacher = req.session.email;
    var form = new formidable.IncomingForm();
        form.parse(req,function(err,fields,files){
            console.log(files.filetoupload.filepath);
            console.log("測試")
            console.log(files);
            console.log("測試")
            console.log(fields);
            console.log(fields.textbar);
            var question = fields.textbarQuestion;
            var answer = fields.textbarAnswer;
            var oldpath = files.filetoupload.filepath;
            var newpath = __dirname+'/photo/' + files.filetoupload.originalFilename
            var type = getFileExtension(files.filetoupload.originalFilename);
            console.log(type);
            if(files.filetoupload.originalFilename){
                if(type=='png'||type=='jpg'){
                    fs.rename(oldpath,newpath,function(err){
                        if(err) throw err;
                        console.log('已完成上傳檔案');  
                        connect.query('insert into `111- E3Web`.AssayQuestion(Question,Answer,PhotoPath,Lesson,Part,Setter,CreateTime) values(?,?,?,?,?,?,?)',[question,answer,files.filetoupload.originalFilename,fields.Lesson,fields.Part,teacher,new Date().toLocaleDateString()+new Date().toLocaleTimeString()],function(err){
                            if(err) throw err;
                            console.log('題目及解答已放入DB');
                        })         
                    })
                    res.redirect('/asking');
                }else{
                    console.log('不能輸入此種類的檔案!!!');
                    res.render('askingwrong1');
                }             
            }else{
                console.log('沒有要上傳的圖檔');
                connect.query('insert into `111- E3Web`.AssayQuestion(Question,Answer,PhotoPath,Lesson,Part,Setter,CreateTime) values(?,?,?,?,?,?,?)',[question,answer,files.filetoupload.originalFilename,fields.Lesson,fields.Part,teacher,new Date().toLocaleDateString()+new Date().toLocaleTimeString()],function(err){
                    if(err) throw err;
                    console.log('題目及解答已放入DB');
                })
                res.redirect('/asking');
            }        
            
        })
           
    
});

function getFileExtension(str){
    var string = str.split('.')
    return string[1];
}




module.exports = router;