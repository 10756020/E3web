var express = require('express');
var router = express.Router();
var formidable = require('formidable');
var fs = require('fs');
var connect = require('../Database/dbconnection.js');
var cookie = require('cookie-parser');
var bodyParser = require('body-parser')

router.get('/',function(req,res,next){
    if(req.session.email&&req.session.status==2){
        res.render('multiplechoice');
    }else if(req.session.status==1||req.session.status==3){
        res.redirect('/');
    }else{
        res.redirect('/login');
    }
    
})

router.post('/',function(req, res, next){
    var form = new formidable.IncomingForm();
    var teacher = req.session.email;
        form.parse(req,function(err,fields,files){
                console.log(files);
            if(fields.myCheckBox){
                console.log('測試1');
                console.log(fields);
                console.log('測試2');
                console.log(files);
                console.log('測試3');
                var question = fields.textbarQuestion;
                var option1 = fields.Option1;
                var option2 = fields.Option2;
                var option3 = fields.Option3;
                var option4 = fields.Option4;
                var answer;
                if(fields.myCheckBox=='checkBox1'){
                    answer = 'Option1';
                    console.log('Option1');
                }else if(fields.myCheckBox=='checkBox2'){
                    answer = 'Option2';
                    console.log('Option2');
                }else if(fields.myCheckBox=='checkBox3'){
                    answer = 'Option3';
                    console.log('Option3');
                }else if(fields.myCheckBox=='checkBox4'){
                    answer = 'Option4';
                    console.log('Option4');
                }
                var oldpath = files.filetoupload.filepath;
                var newpath = __dirname+'/photo/' + files.filetoupload.originalFilename
                var type = getFileExtension(files.filetoupload.originalFilename);
                console.log(type);
                if(files.filetoupload.originalFilename){
                    if(type=='jpg'||type=='png'){
                        fs.rename(oldpath,newpath,function(err){
                            if(err) throw err;
                            console.log('已完成上傳檔案');           
                        })
                        connect.query('insert into `111- E3Web`.MultiplechoiceQuestion(Question,Option1,Option2,Option3,Option4,Answer,PhotoPath,Lesson,Part,Type,Setter,CreateTime) values(?,?,?,?,?,?,?,?,?,?,?,?)',[question,option1,option2,option3,option4,answer,files.filetoupload.originalFilename,fields.Lesson,fields.Part,fields.Type,teacher,new Date().toLocaleDateString()+new Date().toLocaleTimeString()],function(err){
                            if(err) throw err;
                            console.log('題目及解答已放入DB');
                        })
                        res.redirect('/multiplechoice');
                    }else{
                        console.log('不能輸入此種類的檔案!!!');
                        res.render('multiplechoicewrong1');
                    }                   
                }else{
                    console.log('沒有要上傳的圖檔');
                    connect.query('insert into `111- E3Web`.MultiplechoiceQuestion(Question,Option1,Option2,Option3,Option4,Answer,PhotoPath,Lesson,Part,Type,Setter,CreateTime) values(?,?,?,?,?,?,?,?,?,?,?,?)',[question,option1,option2,option3,option4,answer,files.filetoupload.originalFilename,fields.Lesson,fields.Part,fields.Type,teacher,new Date().toLocaleDateString()+new Date().toLocaleTimeString()],function(err){
                        if(err) throw err;
                        console.log('題目及解答已放入DB');
                    })
                    res.redirect('/multiplechoice');
                }                                         
            }else{
                res.redirect('/multiplechoice');
                console.log('請記得選擇正確解答');
            }    
        })
    
})

function getFileExtension(str){
    var string = str.split('.')
    return string[1];
}
module.exports = router;