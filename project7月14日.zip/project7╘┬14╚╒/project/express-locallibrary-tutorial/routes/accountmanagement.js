var express = require('express');
var router = express.Router();
var connect = require('../Database/dbconnection.js');
/* GET users listing. */
router.get('/', function(req, res, next) {
  if(req.session.email&&req.session.status==3){
    connect.query('select serial,email,status from `111- E3Web`.UserData where status=? or status=? order by status,serial asc',['學生','老師'],function(err,user){
        console.log(user);
        res.render('accountmanagement',{users:user });
        
    })   
}else if(req.session.status==1||req.session.status==2){
    res.redirect('/');
}else{
    res.redirect('/login');
}
});

router.get('/:id',function(req,res,next){
    var number = req.params.id;
    console.log(number);
    if(req.session.status==3){
        connect.query('delete from `111- E3Web`.UserData where serial =?',[number],function(err){
            console.log('serial'+number+'已被刪除');
        })
        res.redirect('/accountmanagement');
    }else{
        res.redirect('/');
    }
    
})

router.post('/',function(req,res,next){
  var SearchData = req.body.search;
  var word = '%'+SearchData+'%'
  console.log(SearchData);
  var query ="SELECT serial,email , status FROM `111- E3Web`.UserData where (status = ? || status = ?) && email like ? order by status,serial asc"
  connect.query(query,['老師','學生',word],function(err,search){
      if(search){
          console.log(search)
          res.render('accountmanagement',{users:search})
          
      }else{
          res.render('accountmanagement',{message:'無資料'})
          console.log('查無資料')
      }
      
  })
})


module.exports = router;
