var express = require('express');
var router = express.Router();
var connect = require('../Database/dbconnection.js');
var cookie = require('cookie-parser');
var bodyParser = require('body-parser');
var bcrypt = require('bcrypt');
const saltRound = 5;

router.get('/',function(req,res,next){
    if(req.session.email&&req.session.status==1){
        res.render('studentinfo',{account:req.session.email});
    }else if(req.session.status==2||req.session.status==3){
        res.redirect('/');
    }else{
        res.redirect('/login');
    }
    
})

router.post('/',function(req,res,next){
    var newps = req.body.changedPassword;
    var oldps = req.body.oldPassword;
    var pscheck = req.body.changedPasswordChecked;
    var email = req.session.email
    connect.query('SELECT password FROM `111- E3Web`.UserData WHERE email=?',[email],function(err,ps){
        bcrypt.compare(oldps,ps[0].password).then(function(result){
            console.log(result);
            if(result){
                if(newps==pscheck){
                    connect.query('UPDATE `111- E3Web`.UserData SET password=? where email =?',[bcrypt.hashSync(newps,saltRound),req.session.email],function(err){
                        if(err) throw err;
                        console.log('已成功更改密碼');
                        res.redirect('/');
                    })
                }else{
                    console.log('新密碼輸入不相同喔!');
                    res.render('studentinfowrong2',{account:req.session.email});
                }
            }else{
                console.log('舊密碼輸入錯誤!!!');
                res.render('studentinfowrong1',{account:req.session.email});
            }
        })
    })
    
})


module.exports = router;