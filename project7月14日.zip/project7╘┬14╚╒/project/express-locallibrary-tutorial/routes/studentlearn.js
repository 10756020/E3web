var express = require('express');
var router = express.Router();
var formidable = require('formidable');
var fs = require('fs');
var connect = require('../Database/dbconnection.js');
var cookie = require('cookie-parser');
var bodyParser = require('body-parser');

router.get('/',function(req,res,next){
    if(req.session.email&&req.session.status==1){
        res.render('studentlearn');
    }else if(req.session.status==2||req.session.status==3){
        res.redirect('/');
    }else{
        res.redirect('/login');
    }
    
})

module.exports = router;