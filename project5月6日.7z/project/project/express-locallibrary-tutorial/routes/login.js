var express = require('express');
var router = express.Router();
var connection = require('../Database/dbconnection.js');
var bcrypt = require('bcrypt');
const cookie = require('cookie-parser');

router.get('/',function(req,res,next){
    console.log(req.session.email);
    console.log(req.session.status);
    if(req.session.email&&req.session.status==1){
        res.redirect('/');
    }else if(req.session.email&&req.session.status==2){
        res.redirect('/');
    }else{
        res.render('login');
    }
    
})

router.post('/',function(req,res,next){
    var Email = req.body.email;
    var Ps = req.body.password;
    console.log(Email);
    console.log(Ps);
    connection.query('select * from `111- E3Web`.UserData where email=?',[Email],function(err,user){
        console.log(user.length);
        if(user.length==0){
            console.log('沒有此帳號');
            res.send('沒有此帳號');
        }else{                        
                console.log(user[0].password); 
                req.session.email = Email;
                console.log(req.session.email)
                bcrypt.compare(Ps, user[0].password).then(function (result) {
                    console.log(result);
                    if(result==true){
                        console.log('密碼正確');
                        req.session.user = user;
                        if(user[0].status == '學生'){
                            req.session.status=1;
                            res.redirect('/');
                        }else{
                            req.session.status=2;
                            console.log(req.session.status);
                            res.redirect('/');
                        }
                        
                    }else{
                        console.log('密碼錯誤');
                        res.status(404);
                    }
                  });                            
        }
    })
})






module.exports = router;