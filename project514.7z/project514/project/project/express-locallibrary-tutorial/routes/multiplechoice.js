var express = require('express');
var router = express.Router();
var formidable = require('formidable');
var fs = require('fs');
var connect = require('../Database/dbconnection.js');
var cookie = require('cookie-parser');
var bodyParser = require('body-parser')

router.get('/',function(req,res,next){
    if(req.session.email&&req.session.status==2){
        res.render('multiplechoice');
    }else if(req.session.email){
        res.redirect('/');
    }else{
        res.redirect('/login');
    }
    
})

router.post('/',function(req, res, next){
    var form = new formidable.IncomingForm();
    var teacher = req.session.email;
    form.parse(req,function(err,fields,files){
        if(fields.one||fields.two||fields.three||fields.four){
            console.log('測試1');
            console.log(fields);
            console.log('測試2');
            console.log(files);
            console.log('測試3');
            var question = fields.textbarQuestion;
            var option1 = fields.Option1;
            var option2 = fields.Option2;
            var option3 = fields.Option3;
            var option4 = fields.Option4;
            var answer;
            if(fields.one=='true'){
                answer = 'Option1';
                console.log('Option1');
            }else if(fields.two=='true'){
                answer = 'Option2';
                console.log('Option2');
            }else if(fields.three=='true'){
                answer = 'Option3';
                console.log('Option3');
            }else if(fields.four=='true'){
                answer = 'Option4';
                console.log('Option4');
            }
            var oldpath = files.filetoupload.filepath;
            var newpath = 'C:/Users/Covington/Desktop/專題/project/project/project/express-locallibrary-tutorial/picture/' + files.filetoupload.originalFilename
            if(files.filetoupload.originalFilename){
                fs.rename(oldpath,newpath,function(err){
                    if(err) throw err;
                    console.log('已完成上傳檔案');           
                })
            }else{
                console.log('沒有要上傳的圖檔');
            }          
            connect.query('insert into `111- E3Web`.MultiplechoiceQuestion(Question,Option1,Option2,Option3,Option4,Answer,PhotoPath,Setter) values(?,?,?,?,?,?,?,?)',[question,option1,option2,option3,option4,answer,files.filetoupload.originalFilename,teacher],function(err){
                if(err) throw err;
                console.log('題目及解答已放入DB');
            })
            res.redirect('/multiplechoice');
        }else{
            res.redirect('/multiplechoice');
            console.log('請記得選擇正確解答');
        }    
    })
    
})
module.exports = router;