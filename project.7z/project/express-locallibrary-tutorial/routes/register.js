var express = require('express');
var router = express.Router();
var connect = require('../Database/dbconnection.js');
var bcrypt = require('bcrypt');
const saltRound = 5;
router.get('/',function(req,res,next){
    if(req.session.email&&req.session.status==1){
        res.redirect('/');
    }else if(req.session.email&&req.session.status==2){
        res.redirect('/');
    }else{
        res.render('register');
    }
})
//接受註冊資料
router.post('/',function(req,res,next){
    var Email = req.body.email;
    var Ps = req.body.password;
    var CPs = req.body.confirmpassword;
    console.log(Email);
    console.log(Ps);
    console.log(CPs);
    connect.query('select * from `111- E3Web`.UserData where email=?',[Email],function(err , row){
        console.log(row.length);
        if(row.length>0){
            console.log('已經重複註冊!');
            res.redirect('/registerrepeat');
        }else{
            if(Ps!=CPs){
              console.log('輸入的密碼不相同!!!');
              res.redirect('/registerdifferent');
            }
            else{
              connect.query('insert into `111- E3Web`.UserData(email,password,status,createtime) values (? , ? , ? , ?)',[Email,bcrypt.hashSync(Ps,saltRound),'學生',new Date().toLocaleDateString()],function(err){
                if(err) throw err;
                console.log('已正式註冊成功');
                res.redirect('/login');
            })
            }
           
        }
    })
    
    
    
})


module.exports = router;