var express = require('express');
var router = express.Router();
var connection = require('../Database/dbconnection.js');

router.get('/askinglist',function(req,res,next){
    var teacher = req.session.email;
    console.log(teacher);
    if(req.session.email&&req.session.status==2){
        connection.query('SELECT Question,Answer,PhotoPath from `111- E3Web`.AssayQuestion where Setter=? order by Question desc',[teacher],function(err,question){
            console.log(question);
            res.render('askinglist',{rows:question});
        })
        
    }else if(req.session.email&&req.session.status==1){
        res.redirect('/');
    }else{
        res.redirect('/login');
    }
    
})

router.get('/multiplechoicelist',function(req,res,next){
    var teacher = req.session.email;
    console.log(teacher);
    if(req.session.email&&req.session.status==2){
        connection.query('SELECT Question,Option1,Option2,Option3,Option4,Answer,PhotoPath from `111- E3Web`.MultiplechoiceQuestion where Setter=? order by Question desc',[teacher],function(err,question){
            console.log(question);
            res.render('multiplechoicelist',{rows:question});
        })
        
    }else if(req.session.email&&req.session.status==1){
        res.redirect('/');
    }else{
        res.redirect('/login');
    }
})



module.exports = router;