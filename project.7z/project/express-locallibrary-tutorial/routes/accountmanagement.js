var express = require('express');
var router = express.Router();
var connect = require('../Database/dbconnection.js');
/* GET users listing. */
router.get('/', function(req, res, next) {
  if(req.session.email&&req.session.status==3){
    connect.query('select email,status from `111- E3Web`.UserData where status=? or status=? order by status desc',['學生','老師'],function(err,user){
        console.log(user);
        res.render('accountmanagement',{users:user});
    })
    
}else if(req.session.status==1||req.session.status==2){
    res.redirect('/');
}else{
    res.redirect('/login');
}
});

router.post('/',function(req,res,next){

})

router.get('/createTeacherAccount',function(req,res,next){
  if(req.session.email&&req.session.status==3){
    res.render('createTeacherAccount');
  }else if(req.session.status==1||req.session.status==2){
    res.redirect('/');
  }else{
    res.redirect('/login');
  }
  
})

router.post('/createTeacherAccount',function(req,res,next){

})



module.exports = router;
