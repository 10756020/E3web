var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  var name = req.session.email;
  console.log(req.session.status);
  if(req.session.email&&req.session.status==1){
    res.render('index', { title: name });
  }
  else if(req.session.email&&req.session.status==2){
    res.render('teacherhp', { title: name });
  }
  else{
    res.redirect('/login');
  }
  
});

module.exports = router;
